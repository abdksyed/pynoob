from .CusResNet import CusResNet18, CusResNet34
from .Net import *