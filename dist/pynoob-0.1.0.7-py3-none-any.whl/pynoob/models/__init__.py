from .CusResNet import CusResNet18, CusResNet34
from .Net import *
from .S11_model import S11_Model
from .ResNet_S12 import ResNet18_S12, ResNet34_S12