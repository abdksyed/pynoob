# pynoob

This a DeepLeaning Package build on top of PyTorch for n00bs to get started with ComputerVision Applications.